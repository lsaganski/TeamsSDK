var api;

window.onload = function() {
    var iframe = document.getElementById("extension-tab-frame");
    iframe.parentNode.removeChild(iframe);
    loadPPT();
};

function loadBootstrapperScript(source) {
    var script = document.createElement('script');
    script.src = source;
    script.onload = function(){ webkit.messageHandlers.callbackHandler.postMessage({ "event" : "scriptLoaded" }); }
    document.getElementsByTagName('head')[0].appendChild(script);
}

function loadPPT() {
    webkit.messageHandlers.callbackHandler.postMessage({ "event" : "initialize" });
}

function goToSlide(slideIdx, timeLineMappings) {
    var mapping = JSON.parse(timeLineMappings);
    this.api.GoToSlide(slideIdx, mapping);
}

function next() {
    this.api.Next();
}

function prev() {
    this.api.Prev();
}

function nextSlide() {
    this.api.GoToNextSlide();
}

function prevSlide() {
    this.api.GoToPrevSlide();
}

function viewerEventsHandler(e) {
    switch (e.EventType) {
        case window.ViewerEventType.GetSlidesInShowCount:
            webkit.messageHandlers.callbackHandler.postMessage({ "event" : "slidesCountRead", "slidesCount" : e.SlidesCount });
            break;
        case window.ViewerEventType.GetCurrentPosition:
            webkit.messageHandlers.callbackHandler.postMessage({ "event" : "currentPositionRead", "slideIndex" : e.SlideIndex, "timeLineMappings" : e.TimeLineMappings });
            break;
        case window.ViewerEventType.OnPositionChanged:
            webkit.messageHandlers.callbackHandler.postMessage({ "event" : "positionChanged", "slideIndex" : e.SlideIndex, "timeLineMappings" : e.TimeLineMappings });
            break;
        case window.ViewerEventType.OnError: // crash, internal error
        case window.ViewerEventType.OnApiError:
            webkit.messageHandlers.callbackHandler.postMessage({ "event" : "error", "message" : JSON.stringify(e) });
            break;
    }
}

function initViewer(fileName, wacUrl, contentBundleUrl, fileGetUrl, fileSize, majorVersion, sessionId, locale, userId, hostName, currentSlideIndex) {
    var sessionInformation = {
        "HostName" : hostName,
        "HostSessionId": sessionId,
        "UserId": userId,
        "HostInitTime": new Date(),
        "UiLocale": locale,
        "DataLocale": locale,
        "WdParams": {}
    };
    
    var bundleInfo = {
        "MajorVersion": majorVersion,
        "Url": contentBundleUrl,
    };
    
    var precheckInfo = {
        "FileName": fileName,
        "FileGetUrl": fileGetUrl,
        "FileSize": fileSize || 1,
        "BundleInfo": bundleInfo,
        "CreateNewInfo": null,
    };
    
    var appSettings = {
        "TakeFocusOnBoot": true, // Lets PPT take focus on boot so that arrow keys will cause slide to advance
        "UseTransparentBackground": true,
    };
    
    function OnInitSuccess(api) {
        this.api = api;
        this.api.GoToSlide(currentSlideIndex, []);
        this.api.RegisterEventHandler(e => this.viewerEventsHandler(e));
        this.api.RestoreFocus();
        this.api.GetSlidesInShowCount();
        this.api.GetCurrentPosition();
    }
    
    function OnInitFailure(e) {
        webkit.messageHandlers.callbackHandler.postMessage({ "event" : "initError"});
    }
    
    var anchor = document.getElementsByClassName("extension-tab")[0];
    var initParams = {
        "Container" : anchor,
        "SessionInformation" : sessionInformation,
        "WopiPrecheckInfo" : precheckInfo,
        "ApplicationCustomSettings": appSettings,
        "FnOnInitializeSuccess": OnInitSuccess,
        "FnOnInitializeFailure" : OnInitFailure,
    };
    
    if (currentSlideIndex) {
        // TODO: (suryap/maphi) StartingTimeLineMappings (currently unsupported)
        // Beware: StartingSlideIndex is 1-based while everything else in the WRS Previewer API is 0-based
        initParams.ApplicationCustomSettings['StartingSlideIndex'] = parseInt(currentSlideIndex) + 1;
    }
    
    if (wacUrl) {
        // We set wacUrl for compliance reasons but must avoid WAC fallback
        initParams.ApplicationCustomSettings['EnableWacFallback'] = false;
        initParams['ApplicationUrl'] = wacUrl;
    }
    
    Microsoft.Office.PowerPoint.Bootstrap.Prefetch();
    Microsoft.Office.PowerPoint.Bootstrap.InitializeWopiPending(initParams);
}
