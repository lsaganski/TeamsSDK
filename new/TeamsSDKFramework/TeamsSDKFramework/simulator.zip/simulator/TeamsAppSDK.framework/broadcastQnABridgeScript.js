callbacks = {};
requestId = 0;
logType = {
    LogInfo : 1,
    LogError : 2,
    LogWarning : 3
};

function setupBridge() {
    var jsTabFrame = document.getElementById('extension-tab-frame');
    if (jsTabFrame && jsTabFrame.contentWindow) {
        jsTabFrame.src = "kDestinationURLOrID";
        window.addEventListener("message", (event) => this.postWindowMessage(event), false);
    }
}

function postWindowMessage(event) {
    if (!event || !event.data) {
        this.log("broadcastQnABridgeScript: Invalid event received", this.logType.LogWarning);
        return;
    }
    
    this.processAttendeeQnAMessageRequest(event.source, event.data);
}

function processAttendeeQnAMessageRequest(sourceWindow, eventData) {
    var parsedData = JSON.parse(eventData);
    if (parsedData.event == 'extensions.qna.updateAadToken') {
        this.callbacks[this.requestId] = function(authToken) {
            var response = JSON.stringify({ event: parsedData.event, data: {aadToken: `${authToken}`}});
            sourceWindow.postMessage(response, "*");
            this.log("broadcastQnABridgeScript: Returning aad token to qna website", this.logType.LogInfo);
        }
        
        this.log("broadcastQnABridgeScript: Attendee qna requesting aad token", this.logType.LogInfo);
        webkit.messageHandlers.listener.postMessage({"event" : "QnA", "eventData" : parsedData, "requestId" : this.requestId++});
    }
    else if (parsedData.event == 'extensions.qna.notification') {
        this.log("broadcastQnABridgeScript:New event received");
        webkit.messageHandlers.listener.postMessage({"event" : "QnA", "eventData" : parsedData});
    }
}

function handleResponseFromNative(response, requestId) {
    var callback = (this.callbacks[requestId]).bind(this);
    if (callback) {
        callback(response);
        delete this.callbacks[requestId];
    }
}

function log(info, logType) {
    // Uncomment to generate console logs.
    // console.log(info);
    webkit.messageHandlers.listener.postMessage({"event" : "Log", "logType" : logType, "value" : info });
}

setupBridge();
