//+----------------------------------------------------------------
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Module name: ViewController.h
//----------------------------------------------------------------

#import <UIKit/UIKit.h>
#import <TeamsAppSDK/TeamsAppSDKPublic.h>

@interface ViewController : UIViewController <UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout>

@end

