//+----------------------------------------------------------------
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Module name: MicrosoftTeamsSDK.h
//----------------------------------------------------------------

#ifndef MicrosoftTeamsSDK_h
#define MicrosoftTeamsSDK_h

@protocol MicrosoftTeamsSDKDelegate;

NS_ASSUME_NONNULL_BEGIN
/**
 * EventInfo may have reason key for some events.
 * CallEnded provides reasons for the call ending.
 */
static NSString const *MicrosoftTeamsSDKStringReason = @"reason";

/**
 * EventInfo provides key remoteParticipantCount with the new count as value in case of RemoteParticipantCountChanged type event
 */
static NSString const *MicrosoftTeamsSDKStringRemoteParticipantCount = @"remoteParticipantCount";

/**
 * This class is the top-level entry point for the Microsoft Teams SDK. This is primarily interface to
 * interact with full meeting experience APIs. In order to join a meeting, initialize the SDK
 * and then call one of the meeting join API.
 *
 * For example:
 *
 * [MicrosoftTeamsSDK.sharedInstance initialize ];
 *
 * [MicrosoftTeamsSDK.sharedInstance joinMeetingWith:participantName:error: ];
 *
 */
@interface MicrosoftTeamsSDK : NSObject

+ (instancetype)sharedInstance;

/**
 * MicrosoftTeamsSDK related changes and updates notifications provided by MicrosoftTeamsSDKDelegate
 */
@property (nonatomic, weak) id<MicrosoftTeamsSDKDelegate> delegate;

/**
 * Enable photo sharing within a meeting from the device.
 *
 * The photo sharing is disabled by default.
 *
 * The sharing requires two privacy priviledges:
 *
 *  - Privacy — Photo Library Additions Usage Description
 *  - Privacy — Photo Library Usage Description
 */
@property (nonatomic) BOOL enablePhotoSharing;

/**
 * Disable a warning dialog which is shown when users clicks X (close) on meeting end screen.
 *
 * The dialog warns user that the chat history will not be accessible after user leaves the screen.
 *
 * The user would be taken to root view controller view if disabled.
 * The warning dialog is shown by default. 
 */
@property (nonatomic) BOOL disableMeetingExitWarningDialog;

/**
 * Should disable a view where user can re-join and take a look at the chat message be shown after the meeting has been ended.
 *
 * The user would be navigated back to the app after the meeting has ended if it's disabled.
 *
 * The default value is false and the view would be shown.
 *
 * [MicrosoftTeamsSDK.sharedInstance endMeetingWith: ]; would skip the view even if this is set to false.
 */
@property (nonatomic) BOOL shouldDisableEndCallView;

/**
 * Joined meeting remote participant count.
 *
 * The local user is not included in the count.
 *
 * MicrosoftTeamsSDKDelegate protocol onEvent:eventInfo: is called in case the property has changed.
 */
@property (nonatomic) NSUInteger remoteParticipantCount;

/**
 * This method will initialize all Microsoft Teams SDK internal components which are needed to join a meeting.
 *
 * Note:
 *  - This must be called before calling any other API's.
 */
- (void)initialize;

/**
 * Joins a Microsoft Teams meeting as a guest user.
 * The name given as "participantName" parameter will  be used as
 * participant name in the meeting.
 *
 * The meeting will be joined with microphone unmuted and local video turned off
 *
 * @param meetingUrl The meeting URL to join.
 * @param name The name will be displayed as participant name in the meeting
 * @param error Out parameter to return the status of this API call.
 */
- (void)joinMeetingWith:(NSString *)meetingUrl
            participantName:(NSString *)name
                  error:(NSError **)error;


/**
 * Joins a Microsoft Teams meeting as a guest user. During the meeting join, user will be asked to enter a name before
 * joing the meeting. The name which user entered will be used as participant name in the meeting.
 *
 * The meeting will be joined with microphone unmuted and local video turned off
 *
 * @param meetingUrl The meeting URL to join.
 * @param error Out parameter to return the status of this API call.
 */
- (void)joinMeetingWith:(NSString *)meetingUrl
                  error:(NSError **)error;

/**
 * Joins a Teams meeting as a guest user.
 * The name given as "participantName" parameter will  be used as participant name in the meeting.
 * Set the values for isMicOn and isVideoOn to trun on of off microphone and camera for the meeting after joining the meeting.
 *
 * @param meetingUrl The meeting URL to join.
 * @param name The name will be displayed as participant name in the meeting
 * @param isMicOn Set the microphone to be unmuted or muted
 * @param isVideoOn Set the local camere to be turned on or off
 * @param error Out parameter to return the status of this API call.
 */
- (void)joinMeetingWith:(NSString *)meetingUrl
        participantName:(NSString *)name
                  micOn:(BOOL)isMicOn
                videoOn:(BOOL)isVideoOn
                  error:(NSError **)error;

/**
 * Ends an active meeting if one exists.
 *
 * The meeting end view where user can re-join or navigate to the chat view is not shown.
 * The user is taken right back to the app.
 *
 * No active or on hold meeting would return an error in the error out parameter.
 *
 * @param error Out parameter to return the status of this API call if error occured.
 */
- (void)endMeetingWith:(NSError **)error;

/**
 * After the meeting is joined, user can share screen in the meeting. To enable screen share feature in your application set this property
 *
 * @param isScreenSharingEnabled Set YES to allow screen share feature.
 */
- (void)setScreenSharingEnabledStatus:(BOOL)isScreenSharingEnabled;

/**
 * After the meeting is joined, user can share screen in the meeting.
 * To enable screen share feature and show your application's screen share extension in the broadcast picker view displayed on your device,
 * Set the extension bundle identifier to the screen share extension bundle identifier of your application
 *
 * @param extensionBundleIdentifier Bundle Identifier specific to the screen share extension.
 */
- (void)setExtensionBundleIdentifier:(NSString *)extensionBundleIdentifier;

- (instancetype)init UNAVAILABLE_ATTRIBUTE;

@end

/**
 * The MicrosoftTeamsSDKEventType enum represents events which the MicrosoftTeamsSDKDelegate protocols would use.
 *
 */
typedef NS_ENUM(int, MicrosoftTeamsSDKEventType) {
    /**
     * Call joining has started, but has not been connected yet
     */
    CallConnecting,
    /**
     * The user is waiting in the lobby and has to be accepted to the meeting
     */
    CallWaitingInLobby,
    /**
     * The call connecting has completed succesfully
     */
    CallConnected,
    /**
     * The call or meeting has ended.
     */
    CallEnded,
    /**
     * The joined meeting remote participant count changed
     */
    RemoteParticipantCountChanged
};

/**
 * The MicrosoftTeamsSDKDelegate provides information about the meeting joining state changes.
 * The delegate is called when meeting has started to connect, the user is waiting for somebody
 * to accept them for the lobby, the meeting has connected and when it has ended.
 *
 * Usage:
 *
 * - Add the MicrosoftTeamsSDKDelegate to the class interface which will use it's delegate
 * - Assign the class to the MicrosoftTeamsSDK class delegate property
 *
 *   MicrosoftTeamsSDK.sharedInstance().delegate = self
 *
 * - Add the protocol implementation for
 *
 *  -(void)onEvent:(MicrosoftTeamsSDKEventType)event eventInfo:(NSDictionary * _Nullable )eventInfo;
 *
 */
@protocol MicrosoftTeamsSDKDelegate <NSObject>

@optional
/**
 * Called when any of the MicrosoftTeamsSDKEventType events has happened.
 *
 * The delegate provides call status notifications based on the MicrosoftTeamsSDKEventType
 *
 * MicrosoftTeamsSDKEventType CallEnded provides a reason in the eventInfo
 *
 *  - normal ending of the call: OK
 *  - other reaons: TIMEDOUT_IN_LOBBY, DENIED_IN_LOBBY, REFUSED, BUSY, MISSED, FAILED, CALL_TIMED_OUT, DROPPED, CANCELLED, UNPLACED and GENERIC_ERROR
 *
 * The "reason" string is available from MicrosoftTeamsSDK class as static string name MicrosoftTeamsSDKStringReason
 *
 * MicrosoftTeamsSDKEventType RemoteParticipantCountChanged provides the remoteParticipantCount in the eventInfo.
 *
 * The "remoteParticipantCount" string is available from MicrosoftTeamsSDK class as static string name MicrosoftTeamsSDKStringRemoteParticipantCount
 *
 * Other MicrosoftTeamsSDKEventType's do not provide eventInfo.
 *
 * @param event The event type
 * @param eventInfo Key/value pair of any informational metadata added for the event
 */
- (void)onEvent:(MicrosoftTeamsSDKEventType)event eventInfo:(NSDictionary * _Nullable )eventInfo;

@end

NS_ASSUME_NONNULL_END
#endif /* MicrosoftTeamsSDK_h */
