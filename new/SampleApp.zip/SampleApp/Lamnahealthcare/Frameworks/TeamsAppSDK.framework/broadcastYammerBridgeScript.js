callbacks = {};
requestId = 0;
logType = {
    LogInfo : 1,
    LogError : 2,
    LogWarning : 3
};

var styles = 'body, html {width: 100%; height: 100%; margin: 0; padding: 0; overflow: hidden;};';
window.onload = function() { addStyle(styles) };

function setupBridge() {
    window.addEventListener("message", (event) => this.postWindowMessage(event), false);
    yam.connect.embedFeed({'container'      : '#yammer-embed-container',
                           'config[header]' : false,
                           'config[footer]' : false,
                           'config[theme]'  : 'kTheme',
                           'broadcastId'    : 'kDestinationURLOrID',
                           'jid'            : 'kJoinID',
                           'sid'            : 'kSessionID'});
}

function addStyle(styles) {
    var css = document.createElement('style');
    css.type = 'text/css';
    
    if (css.styleSheet) css.styleSheet.cssText = styles;
    else css.appendChild(document.createTextNode(styles));
    
    document.getElementsByTagName("head")[0].appendChild(css);
    document.getElementById("yammer-embed-container").setAttribute("style", "display: flex; width: 100%; height: 100%; flex-direction: column; overflow: hidden; flex: 1; position: relative;");
    document.getElementById("embed-feed").setAttribute("style", "flex-grow: 1; border: none; margin: 0; padding: 0; flex: 1; flex-direction: column; width: 100%;");
}

function postWindowMessage(event) {
    if (!event || !event.data) {
        this.log("broadcastYammerBridgeScript: Invalid event received", this.logType.LogWarning);
        return;
    }
    
    this.processYammerQnAMessageRequest(event.source, event.data);
}

function processYammerQnAMessageRequest(sourceWindow, eventData) {
    if (eventData.message == 'yam.embed.initialLoginFailure') {
        // We post the add token when we receive initial login failure
        this.callbacks[this.requestId] = function(authToken) {
            var response = {message: 'loginWithAadToken', token: `${authToken}`};
            sourceWindow.postMessage(response, "*");
            this.log("broadcastYammerBridgeScript: Returning aad token to Yammer", this.logType.LogInfo);
        }
        
        this.log("broadcastYammerBridgeScript: Yammer requesting aad token", this.logType.LogInfo);
        webkit.messageHandlers.listener.postMessage({"event" : "Yammer", "eventData" : eventData, "requestId" : this.requestId++});
    }
    else if (eventData.message == 'yam.embed.aadTokenLoginStatus') {
        webkit.messageHandlers.listener.postMessage({"event" : "Yammer", "eventData" : eventData});
    }
}

function handleResponseFromNative(response, requestId) {
    var callback = (this.callbacks[requestId]).bind(this);
    if (callback) {
        callback(response);
        delete this.callbacks[requestId];
    }
}

function log(info, logType) {
    // Uncomment to generate console logs.
    // console.log(info);
    webkit.messageHandlers.listener.postMessage({"event" : "Log", "logType" : logType, "value" : info });
}

setupBridge();
