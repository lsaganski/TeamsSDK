var playerInstance;
var playerVideoBuffer;
var playerAudioBuffer;
var retryCount;
var isRetrying;
var lastCurrentPlayTime;

function initPlayer(srcUrl, bearerToken)
{
    try
    {
        var myOptions = {
            "nativeControlsForTouch": false,
            "techOrder": ["azureHtml5JS", "html5"],
            controls: true,
            autoplay: true,
            logo: { enabled: false },
            width: "100%",
            height: "100%",
        }
        
        this.playerInstance = amp("azuremediaplayer", myOptions);
        this.retryCount = 0;
        this.isRetrying = false;
        
        this.playerInstance.addEventListener(amp.eventName.error, () => { this.handleErrorEvent(); });
        this.playerInstance.addEventListener(amp.eventName.canplaythrough, () => { this.handleCanPlayThroughEvent(); });
        this.playerInstance.addEventListener(amp.eventName.fullscreen, () => { this.handleFullScreenEvent(); });
        this.playerInstance.addEventListener(amp.eventName.click, () => { this.handleVideoFrameClicked(); });
        this.playerInstance.addEventListener(amp.eventName.pause, () => { this.handleVideoPause(); });
        this.playerInstance.addEventListener(amp.eventName.resume, () => { this.handleVideoResume(); });
        this.playerInstance.addEventListener(amp.eventName.play, () => { this.handleVideoPlay(); });
        this.playerInstance.addEventListener(amp.eventName.exitfullscreen, () => { this.handleExitFullScreenEvent(); });
        this.playerInstance.addEventListener(amp.eventName.fullscreenchange, () => { this.handleFullScreenChangeEvent(); });
        this.playerInstance.addEventListener(amp.eventName.loadedmetadata, () => { this.handleLoadedMetadata(); });
        this.playerInstance.addEventListener(amp.eventName.ended, () => { this.handleEnded(); });
        this.playerInstance.addEventListener(amp.eventName.waiting, () => { this.handleWaiting(); });
        this.playerInstance.addEventListener(amp.eventName.playing, () => { this.handlePlaying(); });
        this.playerInstance.addEventListener(amp.eventName.seeking, () => { this.handleSeeking(); });
        this.playerInstance.addEventListener(amp.eventName.seeked, () => { this.handleSeeked(); });
        this.playerInstance.addEventListener(amp.eventName.playbackbitratechanged, () => { this.handlePlaybackBitrateChanged(); });
        this.playerInstance.addEventListener('potentialMediaFreeze', () => { this.handlePotentialMediaFreeze(); });
        
        this.setPlayerSource(srcUrl, bearerToken);
    }
    catch(err)
    {
        webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "error", "message" : err });
    }
}

function handlePotentialMediaFreeze()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "potentialMediaFreeze" });
}

function handlePlaybackBitrateChanged()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "playbackbitratechanged", "bitrate" : this.playerInstance.currentDownloadBitrate });
}

function handleLoadedMetadata()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "loadedmetadata" });
}

function handleFullScreenChangeEvent()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "fullscreenchange" });
}

function handleExitFullScreenEvent()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "exitfullscreen" });
}

function handleVideoPlay()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "play" });
    if (this.retryCount > 0 && this.isRetrying)
    {
        this.playerInstance.currentTime(this.lastCurrentPlayTime);
        
        // reset isRetrying
        this.isRetrying = false;
    }
}

function handleEnded()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "ended" });
}

function handleWaiting()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "waiting" });
}

function handlePlaying()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "playing" });
}

function handleSeeking()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "seeking" });
}

function handleSeeked()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "seeked" });
}

function handleVideoResume()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "resume" });
}

function handleVideoPause()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "pause" });
}

function handleVideoFrameClicked()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "click" });
}

function handleFullScreenEvent()
{
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "fullscreen" });
}

function handleErrorEvent()
{
    var errorDetails = this.playerInstance.error();
    var code = errorDetails.code;
    var message = errorDetails.message;
    var tech = this.playerInstance.currentTechName();
    var version = this.playerInstance.getAmpVersion();
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event",
                                                         "eventName" : "error",
                                                         "message" : message,
                                                         "code" : code,
                                                         "tech" : tech,
                                                         "version" : version });
}

function handleCanPlayThroughEvent()
{
    this.playerVideoBuffer = this.playerInstance.videoBufferData();
    this.playerAudioBuffer = this.playerInstance.audioBufferData();
    
    // Register events callbacks for video buffer
    if (this.playerVideoBuffer) {
        this.playerVideoBuffer.addEventListener(amp.bufferDataEventName.downloadcompleted, () => { this.handleVideoDownloadCompleted(); });
        this.playerVideoBuffer.addEventListener(amp.bufferDataEventName.downloadfailed, () => { this.handleVideoDownloadError(); });
    }
    
    // Register events callbacks for audio buffer
    if (this.playerAudioBuffer) {
        this.playerAudioBuffer.addEventListener(amp.bufferDataEventName.downloadcompleted, () => { this.handleAudioDownloadCompleted(); });
        this.playerAudioBuffer.addEventListener(amp.bufferDataEventName.downloadfailed, () => { this.handleAudioDownloadError(); });
    }
    
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event", "eventName" : "canplaythrough" });
}

function handleVideoDownloadCompleted()
{
    if (this.playerVideoBuffer && this.playerVideoBuffer.downloadCompleted)
    {
        webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event",
                                                             "eventName" : "videoDownloadComplete",
                                                             "size" : this.playerVideoBuffer.downloadCompleted.totalBytes,
                                                             "duration" : this.playerVideoBuffer.downloadCompleted.totalDownloadMs });
    }
}

function handleAudioDownloadCompleted()
{
    if (this.playerAudioBuffer && this.playerAudioBuffer.downloadCompleted)
    {
        webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event",
                                                             "eventName" : "audioDownloadComplete",
                                                             "size" : this.playerAudioBuffer.downloadCompleted.totalBytes,
                                                             "duration" : this.playerAudioBuffer.downloadCompleted.totalDownloadMs });
    }
}

function handleVideoDownloadError()
{
    if (this.playerVideoBuffer && this.playerVideoBuffer.downloadFailed)
    {
        webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event",
                                                             "eventName" : "videoDownloadError",
                                                             "code" : this.playerVideoBuffer.downloadFailed.code,
                                                             "message" : this.playerVideoBuffer.downloadFailed.message,
                                                             "mediaDownloadUrl" : this.playerVideoBuffer.downloadFailed.mediaDownload.url });
    }
}

function handleAudioDownloadError()
{
    if (this.playerAudioBuffer && this.playerAudioBuffer.downloadFailed)
    {
        webkit.messageHandlers.callbackHandler.postMessage({ "type" : "event",
                                                             "eventName" : "audioDownloadError",
                                                             "code" : this.playerAudioBuffer.downloadFailed.code,
                                                             "message" : this.playerAudioBuffer.downloadFailed.message,
                                                             "mediaDownloadUrl" : this.playerAudioBuffer.downloadFailed.mediaDownload.url });
    }
}

function setRetry(isRetrying)
{
    if (isRetrying && this.retryCount < 5)
    {
        this.retryCount++;
        this.isRetrying = true;
    }
    else
    {
        this.isRetrying = false;
    }
}

function setPlayerSource(videoSrc, token)
{
    var sourceContext = null;
    
    var sourceContext = {
        "src": videoSrc,
        "type": "application/vnd.ms-sstr+xml"
    };
    
    if (token)
    {
        sourceContext.protectionInfo = [{ type: "AES", authenticationToken: token }]
    }
    
    // For retry scenario, set the lastCurrentPlayTime if it's not default zero
    var currentPlayTime = this.getCurrentPlayTime();
    if (currentPlayTime > 0)
    {
        this.lastCurrentPlayTime = currentPlayTime;
    }
    
    this.playerInstance.src([sourceContext]);
}

function showPlayerControls()
{
    if (this.playerInstance)
    {
        this.playerInstance.controls(true);
    }
}

function hidePlayerControls()
{
    if (this.playerInstance)
    {
        this.playerInstance.controls(false);
    }
}

function getCurrentPlayTime()
{
    if (this.playerInstance)
    {
        return this.playerInstance.currentTime();
    }
    
    return 0;
}

function fetchAndPostPlaybackDataForScenario(stepScenarioName, eventDuration)
{
    currentPlayPosition = this.playerInstance.currentTime();
    livePosition = this.playerInstance.duration();
    playbackBitrate = this.playerInstance.currentPlaybackBitrate();
    currentDownloadBitrate = this.playerInstance.currentDownloadBitrate();
    perceivedBandwidth = this.playerVideoBuffer ? this.playerVideoBuffer.perceivedBandwidth : 0;
    streamType = this.playerInstance.isLive() ? "LIVE" : "DVR";
    tech = this.playerInstance.currentTechName();
    playerVersion = this.playerInstance.getAmpVersion();
    
    //If the peer to peer SDN client is used, AMP stores it like this (copied from Web client)
    isP2PSdnUsed = !!(this.playerInstance["options_"] && this.playerInstance["options_"].sdn && this.playerInstance["options_"].sdn.name);
    
    audioBufferLength = this.playerAudioBuffer ? this.playerAudioBuffer.bufferLevel : 0,
    videoBufferLength = this.playerVideoBuffer ? this.playerVideoBuffer.bufferLevel : 0,
    
    mediaHeight = this.playerInstance.videoHeight();
    mediaWidth = this.playerInstance.videoWidth();
    playerHeight = this.playerInstance.height();
    playerWidth = this.playerInstance.width();
    
    isFullScreen = this.playerInstance.isFullscreen();
    
    webkit.messageHandlers.callbackHandler.postMessage({ "type" : "logscenario",
                                                         "name" : stepScenarioName,
                                                         "duration" : eventDuration,
                                                         "playPosition" : currentPlayPosition,
                                                         "livePosition" : livePosition,
                                                         "bitrate" : playbackBitrate,
                                                         "downloadBitrate" : currentDownloadBitrate,
                                                         "perceivedBandwidth" : perceivedBandwidth,
                                                         "streamType" : streamType,
                                                         "tech" : tech,
                                                         "version" : playerVersion,
                                                         "isP2PSdnUsed" : isP2PSdnUsed,
                                                         "audioBufferLength" : audioBufferLength,
                                                         "videoBufferLength" : videoBufferLength,
                                                         "mediaHeight" : mediaHeight,
                                                         "mediaWidth" : mediaWidth,
                                                         "playerHeight" : playerHeight,
                                                         "playerWidth" : playerWidth,
                                                         "isFullScreen" : isFullScreen });
}

function cleanUp()
{
    if (this.playerInstance)
    {
        this.playerInstance.removeEventListener(amp.eventName.canplaythrough);
        this.playerInstance.removeEventListener(amp.eventName.error);
        this.playerInstance.removeEventListener(amp.eventName.fullscreen);
        this.playerInstance.removeEventListener(amp.eventName.click);
        this.playerInstance.removeEventListener(amp.eventName.pause);
        this.playerInstance.removeEventListener(amp.eventName.resume);
        this.playerInstance.removeEventListener(amp.eventName.play);
        this.playerInstance.removeEventListener(amp.eventName.exitfullscreen);
        this.playerInstance.removeEventListener(amp.eventName.fullscreenchange);
        this.playerInstance.removeEventListener(amp.eventName.loadedmetadata);
        this.playerInstance.removeEventListener(amp.eventName.ended);
        this.playerInstance.removeEventListener(amp.eventName.waiting);
        this.playerInstance.removeEventListener(amp.eventName.playing);
        this.playerInstance.removeEventListener(amp.eventName.seeking);
        this.playerInstance.removeEventListener(amp.eventName.seeked);
        this.playerInstance.removeEventListener(amp.eventName.playbackbitratechanged);
        this.playerInstance.removeEventListener('potentialMediaFreeze');
        this.playerInstance.dispose();
        this.playerInstance = null;
        this.playerAudioBuffer = null;
        this.playerVideoBuffer = null;
    }
}
