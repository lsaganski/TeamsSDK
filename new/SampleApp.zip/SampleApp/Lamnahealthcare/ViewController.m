//+----------------------------------------------------------------
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Module name: ViewController.m
//----------------------------------------------------------------

#import "ViewController.h"
#import "TeleHealthCollectionViewCell.h"
#import "AppointmentsViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (strong, nonatomic) NSArray *optionLabels;
@property (strong, nonatomic) NSArray *optionImages;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initCollectionView];
    
    self.optionImages = [NSArray arrayWithObjects:@"findDoctor_icon.png", @"healthSummary_icon.png", @"billing_icon.png", @"appointments_icon.png", @"emergency_icon.png", @"medications_icon.png", nil];
    self.optionLabels = [NSArray arrayWithObjects:@"Find Doctor", @"Health Summary", @"Billing", @"Appointments", @"Emergency", @"Medications", nil];
    [self.navigationController.navigationBar setValue:@(YES) forKeyPath:@"hidesShadow"];
    self.navigationController.navigationBar.translucent = NO;
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor], NSFontAttributeName:[UIFont fontWithName:@"Ubuntu-Bold" size:20]}];
}

- (void)initCollectionView
{
    // The the collection view delegates
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    self.collectionView.scrollEnabled = YES;
    UICollectionViewFlowLayout *flowLayout = (UICollectionViewFlowLayout*)self.collectionView.collectionViewLayout;

    flowLayout.sectionInset = UIEdgeInsetsMake(20, 20, 20, 20);
    flowLayout.minimumLineSpacing = 20.0f;
    flowLayout.minimumInteritemSpacing = 20.0f;
}


- (nonnull __kindof UICollectionViewCell *)collectionView:(nonnull UICollectionView *)collectionView cellForItemAtIndexPath:(nonnull NSIndexPath *)indexPath {
    TeleHealthCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"mainPageCell" forIndexPath:indexPath];
    
    NSString *labelText = [self.optionLabels objectAtIndex:indexPath.row];
    UIImage *cellImage = [UIImage imageNamed:[self.optionImages objectAtIndex:indexPath.row]];
    cell.optionsLabel.text = labelText;
    cell.optionsImageView.image = cellImage;
    if(indexPath.row == 0)
    {
        cell.containerView.backgroundColor = [UIColor colorWithRed:199.0/255.0 green:237.0/255.0 blue:227.0/255.0 alpha:1.0];
    }
    
    if(indexPath.row == 1)
    {
        cell.containerView.backgroundColor = [UIColor colorWithRed:205.0/255.0 green:231.0/255.0 blue:250.0/255.0 alpha:1.0];
    }
    
    if(indexPath.row == 2)
    {
        cell.containerView.backgroundColor = [UIColor colorWithRed:213.0/255.0 green:214.0/255.0 blue:253.0/255.0 alpha:1.0];
    }
    
    if(indexPath.row == 3)
    {
        cell.containerView.backgroundColor = [UIColor colorWithRed:250.0/255.0 green:234.0/255.0 blue:196.0/255.0 alpha:1.0];
    }
    
    if(indexPath.row == 4)
    {
        cell.containerView.backgroundColor = [UIColor colorWithRed:252.0/255.0 green:208.0/255.0 blue:208.0/255.0 alpha:1.0];
    }
    
    if(indexPath.row == 5)
    {
        cell.containerView.backgroundColor = [UIColor colorWithRed:213.0/255.0 green:225.0/255.0 blue:248.0/255.0 alpha:1.0];

    }
    return cell;
    
}

- (NSInteger)collectionView:(nonnull UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.optionLabels.count;
}

- (CGSize)collectionView:(UICollectionView *)collectionView
                  layout:(UICollectionViewLayout *)collectionViewLayout
  sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CGFloat numberOfItemsPerRow = 2;
    CGFloat width = (self.collectionView.bounds.size.width - [self getCellSpacing])/numberOfItemsPerRow;

    return CGSizeMake(width, width);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 3)
    {
        UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        UIViewController *vc = [sb instantiateViewControllerWithIdentifier:@"AppointmentsViewController"];
        [self.navigationController pushViewController:vc animated:YES];
    }
    [self.collectionView deselectItemAtIndexPath:indexPath animated:YES];
}

- (IBAction)onMenuButtonClicked:(id)sender {
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController *vc = [sb instantiateViewControllerWithIdentifier:@"HamburgerViewController"];
    [self.navigationController pushViewController:vc animated:YES];

}

- (CGFloat)getCellSpacing
{
    CGFloat spacingBetweenCells = 60;
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        if([[UIScreen mainScreen] bounds].size.width > 400.0)
        {
            spacingBetweenCells = 80;
        }
    }
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        spacingBetweenCells = 100;
    }
    return spacingBetweenCells;
}

@end
