//+----------------------------------------------------------------
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Module name: AppointmentDetailsViewController.swift
//----------------------------------------------------------------

import UIKit


class AppointmentDetailsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, MicrosoftTeamsSDKDelegate {

    @objc public var doctorDetails:NSDictionary = NSDictionary()
    @objc public var servicesOffered:[[String:String]] = []
    @objc public var appointmentCost:String = ""
    @objc public var appointmentDate:String = ""
    @objc public var appointmentTime:String = ""
    @objc public var appointmentType:String = ""
    var numberOfRows:Int = 0

    @IBOutlet weak var doctorNameLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var doctorQualificationLabel: UILabel!
    @IBOutlet weak var joinMeetingDefaultNameButton: UIButton!
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var apptDeatilsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.numberOfRows = self.servicesOffered.count + 5
        
        self.apptDeatilsTableView?.dataSource = self
        self.apptDeatilsTableView?.delegate = self
        
        self.apptDeatilsTableView.isScrollEnabled = true
        self.apptDeatilsTableView?.register(AppointmentImageTableViewCell.nib, forCellReuseIdentifier: AppointmentImageTableViewCell.identifier)
        self.apptDeatilsTableView?.register(ServicesTableViewCell.nib, forCellReuseIdentifier:
            ServicesTableViewCell.identifier)
        self.apptDeatilsTableView?.tableFooterView = UIView()
        self.view.sendSubviewToBack(containerView)
        
        loadDetailsView()
        
        MicrosoftTeamsSDK.sharedInstance().delegate = self
        MicrosoftTeamsSDK.sharedInstance().initialize()
        MicrosoftTeamsSDK.sharedInstance().setScreenSharingEnabledStatus(false)
        MicrosoftTeamsSDK.sharedInstance().enablePhotoSharing = true;
        MicrosoftTeamsSDK.sharedInstance().disableMeetingExitWarningDialog = false;
    }
    
    @IBAction func joinTeamsMeetingDefaultName(_ sender: Any) {
        let urlString = "https://teams.microsoft.com/l/meetup-join/19%3ameeting_M2Y5NTE5ZTktMTBlYy00MjZlLTg5YmEtMmQzNDllMjViZmMx%40thread.v2/0?context=%7b%22Tid%22%3a%2272f988bf-86f1-41af-91ab-2d7cd011db47%22%2c%22Oid%22%3a%22bdedbe9c-2474-4644-b73d-c4945fed53a0%22%7d"
        let participantName = "John S."
        var error: NSError?
        MicrosoftTeamsSDK.sharedInstance().joinMeeting(with: urlString, participantName: participantName, error: &error)
        
        if error != nil {
            throwAlert(error:error!)
        }
    }
    
    func throwAlert(error: NSError) {
            let alert = UIAlertController(title: "SDK Status", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    func getMeetingURLString() -> String {
        let urlString = UserDefaults.standard.string(forKey: "meetingURLKey") ?? ""
        let finalUrlString = urlString == "" ? String(describing: Bundle.main.object(forInfoDictionaryKey: "Teams meeting URL") ?? "") : urlString
        return finalUrlString
    }
    
    func getMeetingParticipantName() -> String {
        let participantName = UserDefaults.standard.string(forKey: "participantNameKey") ?? ""
        let finalParticipantName = participantName == "" ? String(describing: Bundle.main.object(forInfoDictionaryKey: "Participant name") ?? "") : participantName
        return finalParticipantName
    }
    
    func loadDetailsView()
    {
        self.locationLabel.text = self.appointmentType
        self.doctorNameLabel.text = self.doctorDetails["doctorName"] as? String
        self.doctorQualificationLabel.text = self.doctorDetails["doctorQualification"] as? String
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numberOfRows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0
        {
            if let cell = tableView.dequeueReusableCell(withIdentifier:
                ServicesTableViewCell.identifier, for: indexPath) as? ServicesTableViewCell
            {
                cell.serviceLabel.isHidden = true
                cell.amountLabel.isHidden = true
                cell.backgroundColor = UIColor (red: 250.0/255.0, green: 250.0/255.0, blue: 250.0/255.0, alpha: 1.0)
                return cell
            }
        }
        if indexPath.row == 1
        {
            if let cell = tableView.dequeueReusableCell(withIdentifier:
                AppointmentImageTableViewCell.identifier, for: indexPath) as? AppointmentImageTableViewCell
            {
                cell.imgTableViewCellLabel.text = self.appointmentDate
                cell.tableviewCellImageView.tintColor = UIColor (red: 89.0/255.0, green: 193.0/255.0, blue: 166.0/255.0, alpha: 1.0)
                return cell
            }
        }
        if indexPath.row == 2
        {
            if let cell = tableView.dequeueReusableCell(withIdentifier:
                AppointmentImageTableViewCell.identifier, for: indexPath) as? AppointmentImageTableViewCell
            {
                cell.separatorInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: UIScreen.main.bounds.width)
                cell.imgTableViewCellLabel.text = self.appointmentTime
                cell.tableviewCellImageView.image = UIImage.init(named: "clock.png")
                cell.tableviewCellImageView.tintColor = UIColor (red: 89.0/255.0, green: 193.0/255.0, blue: 166.0/255.0, alpha: 1.0)
                return cell
            }
        }
        if indexPath.row == 3
        {
            if let cell = tableView.dequeueReusableCell(withIdentifier:
                ServicesTableViewCell.identifier, for: indexPath) as? ServicesTableViewCell
            {
                cell.serviceLabel.text = "Services"
                cell.backgroundColor = UIColor (red: 250.0/255.0, green: 250.0/255.0, blue: 250.0/255.0, alpha: 1.0)
                cell.serviceLabel.font = UIFont.boldSystemFont(ofSize: 18.0)
                NSLayoutConstraint.activate([
                    cell.serviceLabel.centerYAnchor.constraint(equalTo: cell.centerYAnchor)])
                return cell
            }
        }
        if indexPath.row == (numberOfRows-1)
        {
            if let cell = tableView.dequeueReusableCell(withIdentifier:
                ServicesTableViewCell.identifier, for: indexPath) as? ServicesTableViewCell
            {
                cell.serviceLabel.text = "Total"
                cell.amountLabel.text = self.appointmentCost
                cell.amountLabel.font = UIFont.boldSystemFont(ofSize: 18.0)
                return cell
            }
        }
        
        let services = self.servicesOffered[indexPath.row - 4]
        if let cell = tableView.dequeueReusableCell(withIdentifier:
            ServicesTableViewCell.identifier, for: indexPath) as? ServicesTableViewCell
        {
            cell.serviceLabel.text = services["serviceName"]
            cell.serviceDurationLabel.isHidden = false
            cell.serviceDurationLabel.text = services["serviceDuration"]
            cell.amountLabel.text = services["serviceCost"]
            cell.serviceDurationLabel.textColor = UIColor(red: 89/255.0, green: 193/255.0, blue: 166/255.0, alpha: 1.0)
            return cell
        }
        
        return UITableViewCell()
    }
    

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0
        {
            return 30
        }
        if indexPath.row == 3
        {
            return 80
        }
        else
        {
            return 60
        }
    }
    @IBAction func backToAppointments(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    func onEvent(_ event: MicrosoftTeamsSDKEventType, eventInfo: [AnyHashable : Any]? = [:]) {
        print("MicrosoftTeamsSDKEventType EventType was sent: \(event.rawValue)")
        print("MicrosoftTeamsSDKEventType Remote participant count: \(MicrosoftTeamsSDK.sharedInstance().remoteParticipantCount)")
        switch event {
            case .CallConnecting:
                print("MicrosoftTeamsSDKEventType: Call is connecting")
            case .CallConnected:
                print("MicrosoftTeamsSDKEventType: Call is connected")
            case .CallWaitingInLobby:
                print("MicrosoftTeamsSDKEventType: Waiting in lobby")
            case .CallEnded:
                let reason = eventInfo?[MicrosoftTeamsSDKStringReason] as? String ?? ""
                print("MicrosoftTeamsSDKEventType: Call ended with \(reason)")
            case .RemoteParticipantCountChanged:
                let count = eventInfo?[MicrosoftTeamsSDKStringRemoteParticipantCount] as? String ?? ""
                print("MicrosoftTeamsSDKEventType: Remote participant count: \(count)")
            default:
                print("MicrosoftTeamsSDKEventType: Unsupported event type")
        }
    }
}
