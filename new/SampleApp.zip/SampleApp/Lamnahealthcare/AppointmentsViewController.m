//+----------------------------------------------------------------
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Module name: AppointmentsViewController.m
//----------------------------------------------------------------

#import "AppointmentsViewController.h"
#import "AppointmentTableViewCell.h"
#import "Lamnahealthcare-Swift.h"

@interface AppointmentsViewController ()

@property (strong,nonatomic) NSMutableArray* results;
@property (strong,nonatomic) NSMutableArray* appointmentNames;
@property (strong,nonatomic) NSMutableArray* appointmentTimes;
@property (strong,nonatomic) NSMutableArray* appointmentCost;
@property (strong,nonatomic) NSMutableArray* appointmentType;
@property (strong,nonatomic) NSDictionary* doctorNames;
@property (strong,nonatomic) NSString* appointmentDate;
@end

@implementation AppointmentsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.appointmentsTableView.delegate = self;
    self.appointmentsTableView.dataSource = self;
    
    self.appointmentsTableView.scrollEnabled = YES;
    [self.appointmentsTableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    [self.view sendSubviewToBack:_backgroundView];
    NSDictionary *appointments = [self JSONFromFile];

    
    self.results = [appointments valueForKey:@"appointment"];
    [self loadAppointmentDetails:self.results];
}

-(void)loadAppointmentDetails:(NSMutableArray*)results
{
    _appointmentNames = [NSMutableArray new];
    _appointmentTimes = [NSMutableArray new];
    _appointmentCost = [NSMutableArray new];
    _appointmentType = [NSMutableArray new];
    _doctorNames = [NSDictionary new];
    for(NSDictionary *appointmentDict in self.results)
    {
        [_appointmentNames addObject:appointmentDict[@"appointmentName"]];
        [_appointmentTimes addObject:appointmentDict[@"appointmentTime"]];
        [_appointmentCost addObject:appointmentDict[@"appointmentCost"]];
        [_appointmentType addObject:appointmentDict[@"appointmentType"]];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.results.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   AppointmentTableViewCell *cell = [self.appointmentsTableView dequeueReusableCellWithIdentifier:@"AppointmentsCell" forIndexPath:indexPath];
    _doctorNames = self.results[indexPath.section][@"doctor"];
    cell.apptNameLabel.text = self.appointmentNames[indexPath.section];
    cell.apptTimeLabel.text = self.appointmentTimes[indexPath.section];
    cell.docNameLabel.text = _doctorNames[@"doctorName"];
    cell.layer.cornerRadius = 5;
    cell.clipsToBounds = YES;
    return cell;

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 125;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(section == 0)
    {
        return 55;
    }
    return 25;
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    UIView *backgroundView = [[UIView alloc] initWithFrame:header.bounds];
    backgroundView.backgroundColor = [UIColor whiteColor];
    header.backgroundView = backgroundView;
    if (section == 0)
    {
        [header.textLabel setTextColor:[UIColor grayColor]];
        NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"LLLL dd, yyyy"];
        [dateFormatter setTimeZone:[NSTimeZone localTimeZone]];
        header.textLabel.font = [UIFont fontWithName:@"Ubuntu-Bold" size:14];
        self.appointmentDate = [dateFormatter stringFromDate:[NSDate date]];
        [header.textLabel setText:self.appointmentDate];
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    AppointmentDetailsViewController *vc = [sb instantiateViewControllerWithIdentifier:@"AppointmentDetailsViewController"];

    vc.doctorDetails = self.results[indexPath.section][@"doctor"];
    vc.servicesOffered = self.results[indexPath.section][@"servicesOffered"];
    vc.appointmentDate = self.appointmentDate;
    vc.appointmentTime = self.appointmentTimes[indexPath.section];
    vc.appointmentCost = self.appointmentCost[indexPath.section];
    vc.appointmentType = self.appointmentType[indexPath.section];
    [self.navigationController pushViewController:vc animated:YES];
    
}

- (NSDictionary *)JSONFromFile
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"appointment_details" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    return [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
}

- (IBAction)onBackPressed:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

@end
