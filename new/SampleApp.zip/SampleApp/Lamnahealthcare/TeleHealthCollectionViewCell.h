//+----------------------------------------------------------------
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Module name: TeleHealthCollectionViewCell.h
//----------------------------------------------------------------

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TeleHealthCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIView *containerView;
@property (weak, nonatomic) IBOutlet UIImageView *optionsImageView;
@property (weak, nonatomic) IBOutlet UILabel *optionsLabel;

@end

NS_ASSUME_NONNULL_END
