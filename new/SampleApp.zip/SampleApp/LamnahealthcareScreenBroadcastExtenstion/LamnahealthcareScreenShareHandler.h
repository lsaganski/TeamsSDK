#import <ReplayKit/ReplayKit.h>

@interface LamnahealthcareScreenShareHandler : RPBroadcastSampleHandler
{
    NSUserDefaults *sharedUserDefaults;
    NSMutableData *frameData;
};

@end
