//
//  JSFrameWebModule.js
//  TeamSpaceApp
//
//  Copyright © 2018 Microsoft Corporation. All rights reserved.
//

window.frameInterface = {
    // Initializes the frame interface with the URL.
    initialize: function (url) {
        // Validate URL. Must be valid HTTPS URL.
        if (typeof url !== 'string' || !url) {
            console.error("URL is invalid.");
            return;
        }
        
        if (!url.match('^https')) {
            console.error("URL must use HTTPS.");
            return;
        }
        
        // Validate frame exists.
        var frame = document.getElementById('extension-tab-frame');
        frame.style.background = 'white';
        this.frameWindow = frame.contentWindow;
        
        if (!frame || !this.frameWindow) {
            console.error("Couldn't find a frame to host the content.");
            return;
        }
        
        // Attach a listener for message events.
        window.addEventListener('message', function (event) { window.frameInterface.processMessage(event) }, false);
        console.debug("Attached listener for message events.");
        
        // Update the frame source.
        frame.src = url;
        
        // Overrite native interface to post to the correct window.
        window.nativeInterface.postSdkResponse = function(sdkWindow, response) {
            sdkWindow.postMessage(response, "*");
        }
    },

    // Processes the message received by the document window.
    processMessage: function (event) {
        console.debug("Received an event.");

        if (event.source !== this.frameWindow) {
            console.warn("Received an event from an unknown frame window.");
            return false;
        }
        
        request = new window.nativeInterface.sdkRequest(event.data.id, event.data.func, event.data.args);
        window.nativeInterface.processMessageRequest(event.source, request);
    }
}
