//+----------------------------------------------------------------
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Module name: TeamsAppSDK.h
//----------------------------------------------------------------

#ifndef TeamsAppSDK_h
#define TeamsAppSDK_h

#import <TeamsAppSDK/TeamsAppSDK-umbrella.h>

//! Project version number for TeamsAppSDK.
FOUNDATION_EXPORT double TeamsAppSDKVersionNumber;

//! Project version string for TeamsAppSDK.
FOUNDATION_EXPORT const unsigned char TeamsAppSDKVersionString[];

#endif /* TeamsAppSDK_h */
