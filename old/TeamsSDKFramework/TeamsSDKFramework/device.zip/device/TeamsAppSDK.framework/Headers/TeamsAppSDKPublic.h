//+----------------------------------------------------------------
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Module name: TeamsAppSDKPublic.h
//----------------------------------------------------------------

#ifndef TeamsAppSDKPublic_h
#define TeamsAppSDKPublic_h

#import <TeamsAppSDK/MSTUIApplication.h>

#endif /* TeamsAppSDKPublic_h */

