//+----------------------------------------------------------------
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Module name: TeleHealthCollectionViewCell.m
//----------------------------------------------------------------

#import "TeleHealthCollectionViewCell.h"

@implementation TeleHealthCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.backgroundColor = [UIColor clearColor];
    
    UIView* cellView = [[UIView alloc] initWithFrame:self.bounds];
    cellView.backgroundColor = [UIColor whiteColor];
    self.backgroundView = cellView;
    
    UIView* selectedView = [[UIView alloc] initWithFrame:self.bounds];
    selectedView.backgroundColor =[UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1.0];
    self.selectedBackgroundView = selectedView;
}

@end
