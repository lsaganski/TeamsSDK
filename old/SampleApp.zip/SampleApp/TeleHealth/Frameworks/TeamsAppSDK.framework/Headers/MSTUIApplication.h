//+----------------------------------------------------------------
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Module name: MSTUIApplication.h
//----------------------------------------------------------------

#ifndef MSTUIApplication_h
#define MSTUIApplication_h

NS_ASSUME_NONNULL_BEGIN

/**
 * This class is the top-level entry point for the Teams SDK. This is primarily interface to
 * interact with full meeting experience APIs. In order to join a meeting, initialize the SDK
 * and then call one of the meeting join API.
 *
 * For example:
 *
 * [MSTUIApplication.sharedInstance initialize ];
 *
 * [MSTUIApplication.sharedInstance joinMeetingWith:meetingUrl
 *                                  participantName:name
 *                                              error:error ];
 *
 */
@interface MSTUIApplication : NSObject

+ (instancetype _Nullable )sharedInstance;

/**
 * This method will initialize all Teams SDK internal components which are needed to join a meeting.
 *
 * Note:
 *  - This must be called before calling any other API's.
 */
- (void)initialize;

/**
 * Joins a Teams meeting as a guest user. The name given as "participantName" parameter will  be used as
 * participant name in the meeting.
 *
 * @param meetingUrl The meeting URL to join.
 * @param name The name will be displayed as participant name in the meeting
 * @param error Out parameter to return the status of this API call.
 */
- (void)joinMeetingWith:(NSString *)meetingUrl
            participantName:(NSString *)name
                  error:(NSError **)error;


/**
 * Joins a Teams meeting as a guest user. During the meeting join, user will be asked to enter a name before
 * joing the meeting. The name which user entered will be used as participant name in the meeting.
 *
 * @param meetingUrl The meeting URL to join.
 * @param error Out parameter to return the status of this API call.
 */
- (void)joinMeetingWith:(NSString *)meetingUrl
                  error:(NSError **)error;

- (instancetype)init UNAVAILABLE_ATTRIBUTE;

@end

NS_ASSUME_NONNULL_END
#endif /* MSTUIApplication_h */
