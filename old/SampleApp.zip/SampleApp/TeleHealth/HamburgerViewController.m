//+----------------------------------------------------------------
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Module name: HamburgerViewController.m
//----------------------------------------------------------------

#import "HamburgerViewController.h"
#define NON_BREAKING_SPACE  @"\u00a0"

@interface HamburgerViewController ()

@end

@implementation HamburgerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configureTextFields];
    [self configureTapGestureRecognizer];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

-(void)configureTapGestureRecognizer
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc ] initWithTarget:self action:@selector(handleTap:)];
    [self.view addGestureRecognizer:tap];
}

- (void) handleTap:(UITapGestureRecognizer *)recognizer
{
    [self.view endEditing:YES];
}

-(void)configureTextFields
{
    [self.teamsMeetingTextField setBorderStyle:UITextBorderStyleRoundedRect];
    [self.guestNameTextField setBorderStyle:UITextBorderStyleRoundedRect];
    self.teamsMeetingTextField.placeholder = [[[NSAttributedString alloc ] initWithString:@"Teams meeting URL"
                                                                               attributes:@{NSForegroundColorAttributeName : UIColor.lightGrayColor}] string];
    self.guestNameTextField.placeholder = [[[NSAttributedString alloc ] initWithString:@"Participant name"
                                                                               attributes:@{NSForegroundColorAttributeName : UIColor.lightGrayColor}] string];
    self.teamsMeetingTextField.delegate = self;
    self.guestNameTextField.delegate = self;
}

- (IBAction)onBackPressed:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)onSaveButtonPressed:(id)sender
{
    NSString *meetingURLString = self.teamsMeetingTextField.text;
    NSString *participantName = self.guestNameTextField.text;
    NSURL *url = [NSURL URLWithString:meetingURLString];
    NSString *message = @"";
    
    if (!url || [self isEmptyString:meetingURLString])
    {
        message = @"Invalid URL";
        [self throwAlert:message];
    }
    else
    {
        if ([self isEmptyString:participantName])
        {
            participantName = @"";
        }
        
        [[NSUserDefaults standardUserDefaults] setObject:meetingURLString forKey:@"meetingURLKey"];
        [[NSUserDefaults standardUserDefaults] setObject:participantName forKey:@"participantNameKey"];
        message = @"URL Saved Successfully";
        [self throwAlert:message];
    }
}

- (BOOL)isEmptyString:(id)string
{
    static dispatch_once_t onceToken;
    static NSCharacterSet *whitespaceCharSet = nil;
    dispatch_once(&onceToken, ^{
        NSMutableCharacterSet *spaceCharSet = [NSMutableCharacterSet characterSetWithCharactersInString:NON_BREAKING_SPACE];
        [spaceCharSet formUnionWithCharacterSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        whitespaceCharSet = spaceCharSet;
    });
    
    if (![string isKindOfClass:[NSString class]])
        return YES;
    return string == nil || [string isEqualToString:@""] || [string stringByTrimmingCharactersInSet:whitespaceCharSet].length <= 0;
}

- (void)throwAlert:(NSString *)message
{
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@""
                                                                             message:message
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK"
                                                       style:UIAlertActionStyleDefault
                                                     handler:nil];
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}

@end
